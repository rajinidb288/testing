const express=require('express');
const route = express.Router();
const multer=require('multer');
const image=require('../model/user');
const services=require('../services/render');
//const upload=require('../middleware/upload');
const user1=require('../controller/user');

route.get('/uploadphoto',services.uploadphoto);
route.get('/',services.homeRoutes);
route.get('/view/dashboard',services.dashboard);
route.get('/add-user',services.add_user);
route.get('/user-login',services.user_login);

route.get('/session',services.session_set);


route.get('/update-user/:id',services.update_user);
//api
route.post('/api/users',user1.create);

route.get('/route/logout',user1.logout);


route.post('/route/login',user1.login);
route.get('/api/users',user1.find);
route.put('/api/users/:id',user1.update);
route.delete('/api/users/:id',user1.delete);

// var storage = multer.diskStorage({
//     destination: function(req, file, callback) {
//         callback(null, "./assets/img/");
//     },
//     filename: function(req, file, callback) {
//         callback(null, file.fieldname + "_" + Date.now() + "_" + file.originalname);
//     }
// });
//   var upload = multer({
//     storage: storage
// }).array("imgUploader", 3);


// route.post("/uploadphotos", function(req, res) {
//     console.log(req)
//     upload(req, res, function(err) {
//         const user=new image({
       
//           img:req.file.originalname
            
           
//            })
//           console.log('img:',req.file.originalname)
//            //save user in the database
          
//            user
//             .save(user)
//             .then(data=>{
//                // res.send(data)
          
//                res.redirect('/add-user')
          
//            })
//            .catch(err=>{
//                res.status(500).send({
//                    message:err.message|| 'some error occured'
//                });
          
//            });
//         return res.end("File uploaded sucessfully!.");
//     });
// });



module.exports=route;