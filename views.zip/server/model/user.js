const mongoose = require('mongoose');

var schema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true
    },

    //image:{data:Buffer,contentType: String},
   
        gender: String,
        status: String

     
    
});

var imgSchema = mongoose.Schema({
    img:{data:Buffer,contentType: String}
});
const image = mongoose.model("image",imgSchema); 

const Userdb=mongoose.model('userdb',schema);
module.exports=Userdb;