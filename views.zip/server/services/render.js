const axios=require('axios');

exports.homeRoutes=(req,res)=> {
    req.session.name="rajini";
    axios.get('http://localhost:3000/api/users')
    .then(function(response)
    {
        //console.log(response.data)
        res.render('index',{users:response.data});
    })
    .catch(err=>{
        res.send(err)
    })
}

exports.dashboard = (req, res) =>{
    res.render('dashboard');
}

exports.uploadphoto = (req, res) =>{
    res.render('image_uploads');
}

exports.add_user = (req, res) =>{
    res.render('add_user');
}

exports.user_login = (req, res) =>{
    res.render('base');
}

exports.session_set = (req, res) =>{
      var name=req.session.name;
     return res.send(name)
     }

exports.update_user=(req,res)=> {

    //res.render('update_user',{user:"newdata"});
console.log(req);
    // axios.post('http://localhost:3000/api/users',{params:{id:req.query.id}})
    //  //axios.get('http://localhost:3000/api/users')
    // .then(function(userdata){
       
    // res.render('update_user',{user:userdata.data});

        
    // })
    // .catch(err=>{
    //     res.send(err)
    // })




}
